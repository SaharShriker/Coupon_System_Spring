package com.jb.coupon_system_spring.exceptions;

public class CouponException extends Exception{
    public CouponException() {
    }

    public CouponException(String message) {
        super(message);
    }
}
