package com.jb.coupon_system_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponSystemSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
